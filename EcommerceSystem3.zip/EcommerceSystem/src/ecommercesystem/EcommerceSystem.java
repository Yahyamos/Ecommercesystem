/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ecommercesystem;
import java.util.Scanner ;

public class EcommerceSystem {


     
    public static void main(String[] args) {

Scanner input =new Scanner(System.in);

      
        System.out.println("Please enter your id :");
        int id1=input.nextInt();

        System.out.println("Please enter your name :");
        String name1=input.nextLine();
        
        System.out.println("Please enter your adress :");
        String adress1 =input.nextLine();


        Customer customer=new Customer();
         customer.setCustomerId(id1);
        customer.setName(name1);
         customer.setAddress(adress1);
        
        System.out.println(customer.getName());
        System.out.println(customer.getAddress());
        System.out.println(customer.getCustomerId());
       
        System.out.println("How many products you want to add to your cart");
        int num=input.nextInt();
        
        Cart cart1 = new Cart();
      
        ;
        Product product1=new Product(1321, "Smartphone", (float)599.99);
        Product product2=new Product(1321, "T-shirt", (float)19.99);
        Product product3=new Product(1321, "book", (float)39.99);
      
            System.out.println("Which product would you like to add : 1- smartphone  2- T-shirt  3- book ");
            int choice=input.nextInt();
            if(choice==1){
                       cart1.addProduct(product1); 
                    }
            else if(choice==2)
            {
                cart1.addProduct(product2);
            }
            else if(choice==3)
            {
                cart1.addProduct(product3);
            }
       
        }
        float totalPrice = cart1.calculatePrice();
        System.out.println("Your total is "+totalPrice);
        Order order1=new Order(1, 1,(float)totalPrice, cart1);
        
        System.out.println();
        cart1.placeorder();
        int answer = input.nextInt();
        if(answer==1){
             order1.printOrderInfo();
        }
        
       \
































    }
    
}
