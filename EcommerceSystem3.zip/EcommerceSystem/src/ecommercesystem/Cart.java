/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecommercesystem;


public class Cart {
    
    
     private int customerId ;
     private int nproducts ;
     private Product [] products = new Product [ nproducts] ;
     private int num_of_products;

    public Cart(int customerId, int nproducts, int num_of_products) {
        this.customerId = customerId;
        this.nproducts = nproducts;
        this.num_of_products = num_of_products;
    }

    Cart() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

     
    public void setCustomerId(int customerId) {
        this.customerId = Math.abs(customerId);
    }

    public void setNproducts(int nproducts) {
         this.nproducts = Math.abs(nproducts);
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getNproducts() {
        return nproducts;
    }

    public Product[] getProducts() {
        return products;
    }
     
     public void addProduct(Product p){  
           products[num_of_products]=p;
          num_of_products++;
     
    }
  public void removeProduct(int index){
       //if(index>=0 && index <nProducts){
          for(int i=index;i<nproducts;i++){
             products[i]=null;
          }
  }
  public  int calculatePrice(){
       int totalprice=0;
       for (int i =0;i<nproducts;i++){
          totalprice+=products[i].getPrice();
       }
       return totalprice;
       
    }
        
   
    public void placeorder(){
       System.out.println("Would you like to place your order? -1 Yes -2 No");
    }

   public void ShowProduct(){
      for(int i=0;i<num_of_products;i++)
      System.out.println(products[i].getName()+"-$"+products[i].getPrice());
    }
    
    
     
}
