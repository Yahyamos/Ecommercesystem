/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecommercesystem;

/**
 *
 * @author Disha
 */
public class Order {
     private int customerId ;
     private int orderId ;
     private  Cart c1 = new Cart();
     private  int x = c1.getNproducts();
     private Product [] products = new Product [x] ;
     private float totalPrice ;
     
              
              
    public void setCustomerId(int customerId) {
        this.customerId = Math.abs(customerId);
    }

    public void setOrderId(int orderId) {
        this.orderId = Math.abs(orderId);
    }

    public void setProducts(Product[] products) {
        
        this.products = products;
    }

    public void setTotalPrice(float totalPrice) {
          totalPrice = 0;
        for (Product product : products) {
            totalPrice += product.getPrice();
        this.totalPrice = Math.abs(totalPrice);
    }
    }
    public int getCustomerId() {
        return customerId;
    }

    public int getOrderId() {
        return orderId;
    }

    public Product[] getProducts() {
        return products;
    }

    public float getTotalPrice() {
        return totalPrice;
    }
     
    
   
       public void printOrderInfo(){
        System.out.println("Here's your order summary : ");
        System.out.println("OrderId : "+orderId);
        System.out.println("CustomerId : "+customerId);
        System.out.println("Total price : $ "+totalPrice);
        System.out.println("Products : ");
         c1.ShowProduct();
        
        
        
        
    }

     
}
    

