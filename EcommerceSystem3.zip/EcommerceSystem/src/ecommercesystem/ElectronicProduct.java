/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecommercesystem;

/**
 *
 * @author Disha
 */
public class ElectronicProduct extends Product {
    private String brand ;
    private int warrantyPeriod ;

    public ElectronicProduct(int productId, String name, float price) {
        super(productId, name, price);
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }
    
    public void setWarrantyPeriod(int warrantyPeriod) {        
            this.warrantyPeriod = Math.abs(warrantyPeriod);   
    }

    public String getBrand() {
        return brand;
    }

    public int getWarrantyPeriod() {
        return warrantyPeriod;
    }
    
    
    
    
    
    
    
    
    
    
    
}
